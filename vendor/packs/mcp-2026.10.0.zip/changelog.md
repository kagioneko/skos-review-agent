# Changelog

## 2026.10.0

- First release: MCP-001 to MCP-009 across four report groups
  (capability, exposure, impact, defense).
- Inputs can be generated from an MCP client config with `skos scan mcp`.
